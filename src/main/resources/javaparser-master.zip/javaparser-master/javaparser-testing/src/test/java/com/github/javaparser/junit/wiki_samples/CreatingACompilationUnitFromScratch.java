package com.github.javaparser.junit.wiki_samples;

import org.junit.Test;

public class CreatingACompilationUnitFromScratch {
    @Test
    public void printingTheCompilationUnitToSystemOutput() throws Exception {
        ClassCreator.main(new String[]{});
    }
}
