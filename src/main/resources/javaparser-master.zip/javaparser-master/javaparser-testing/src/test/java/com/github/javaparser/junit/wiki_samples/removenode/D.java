package com.github.javaparser.junit.wiki_samples.removenode;

public class D {

    public int foo(int e) {
        int a = 20;
        return a;
    }
}