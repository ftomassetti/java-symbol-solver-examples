package com.github.javaparser.junit.wiki_samples;

public class TestFile {
    public int foo(int e) {
        int a = 20;
        return a;
    }

    public void abc() {

    }

    public int def() {
        return 10;
    }
}
