/**
 * This package contains class for doing some stuff.
 */
@C
package com.company.stuff;