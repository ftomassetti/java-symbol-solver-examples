package com.github.javaparser;

public class ParserConfiguration {
    public boolean doNotAssignCommentsPrecedingEmptyLines = true;
    public boolean doNotConsiderAnnotationsAsNodeStartForCodeAttribution = false;
}